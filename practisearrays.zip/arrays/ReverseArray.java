package com.arrays;

import java.util.Scanner;

public class ReverseArray {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter limit of array :");
			int limit=sc.nextInt();
			int arr[]=new int[limit];
			
			for(int i=0; i<limit; i++) {
				System.out.printf("Enter elements of array[%d]:",i);
				arr[i]=sc.nextInt();
				
			}
			
			for(int i=limit-1; i>=0; i--) {
				System.out.println("Reverse of arry:"+arr[i]);
				
				
			}
	}

}
