package com.arrays;

public class LiterlWay {
	public static void main(String[] args) {
		
		
		String names[]= {"BestFriends","Mrudula","Samhitha","Manju","Madhu","Sunil"};
		
		System.out.println("  ==========        Normal way    ==========");
		System.out.println("Out put of literal way is :"+names[0]);
		System.out.println("Out put of literal way is :"+names[1]);
		System.out.println("Out put of literal way is :"+names[2]);
		System.out.println("Out put of literal way is :"+names[3]);
		System.out.println("Out put of literal way is :"+names[4]);
		System.out.println("Out put of literal way is :"+names[5]);
		System.out.println();
		
		System.out.println("  ==========        By usung Forloop    ==========");
		System.out.println();
		for(int i=0; i<6; i++) {
			System.out.println("Output of literlway by using forloop :"+names[i]);
			
		}
		System.out.println();
		System.out.println("  ==========        By usung length property    ==========");
		System.out.println();
		for(int i=0; i<names.length; i++) {
			System.out.println("Output of literlway by using length property :"+names[i]);
			
		}
		
		System.out.println();
		System.out.println("  ==========        By usung Foreach   ==========");
		System.out.println();
		for(String kanna:names) {
			System.out.println("Output of literlway by using Foreach :"+kanna);
		}
		
	}

}
