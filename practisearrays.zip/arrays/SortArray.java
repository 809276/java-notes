package com.arrays;

import java.util.Arrays;

public class SortArray {
public static void main(String[] args) {
	
	int arr[]= {12,54,67,89,13,56,76,92,80};
	
	System.out.println("Original Array :"+Arrays.toString(arr));
	System.out.println();
	Arrays.sort(arr);
	System.out.println("Sorted Array :"+Arrays.toString(arr));
}
}
