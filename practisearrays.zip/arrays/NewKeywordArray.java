package com.arrays;

public class NewKeywordArray {
public static void main(String[] args) {
	
	
	int arr[]=new int[6];
	arr[0]=12;
	arr[1]=23;
	arr[2]=34;
	arr[3]=45;
	arr[4]=56;
	arr[5]=67;
	
	// Executing normaly
	System.out.println("array values :"+arr[0]);
	System.out.println("array values : "+arr[1]);
	System.out.println("array values : "+arr[2]);
	System.out.println("array values : "+arr[3]);
	System.out.println("array values : "+arr[4]);
	System.out.println("array values : "+arr[5]);
	
	System.out.println("            ==============By Using for loop=========    ");
	// Executing by using for loop
	for(int i=0; i<6; i++) {
		System.out.println(" The values of for loop array :"+arr[i]);
		
		
		
		System.out.println("            ==============By Using foreach loop=========    ");
		
		
		for(int kanna:arr) {
			System.out.println("The values of foreach loop array : "+kanna);
		}
	}
	
}
}
