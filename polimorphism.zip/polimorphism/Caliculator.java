package com.polimorphism;

public class Caliculator {
	
	public void addition(int a ,int b,int c) {
		 System.out.println(" addition of thraee int values:"+(a+b+c));
	 }
	
 public void addition(int a ,int b) {
	 System.out.println(" addition of two int values:"+(a+b));
 }
 
 public void addition(float a ,float b) {
	 System.out.println(" addition of two float values:"+(a+b));
 }
 
 public void addition(int a ,float b) {
	 System.out.println(" addition of int, float values:"+(a+b));
 }
 public void addition(float a ,int b) {
	 System.out.println(" addition of int, float values:"+(a+b));
 }
 public static void main(String[] args) {
	Caliculator ct=new Caliculator();
	ct.addition(12.43f, 12.43f);
	ct.addition(12.12f, 60);
	ct.addition(43, 12.0f);
	ct.addition(12,120);
	ct.addition(1, 4,3);
	
}
}
