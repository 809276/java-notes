package com.polimorphism;

class Notification{
public void sendnotification() {
	System.out.println("normal notification");
}
}
class Emailnotification extends Notification{
	
	@Override
	public void sendnotification() {
		System.out.println("Email notification");
	}
}




public class WhatsupNotification extends Notification{
	
	@Override
	public void sendnotification() {
		System.out.println("whatsup notification");
	}
public static void main(String[] args) {
	Notification nt=new Notification();
	Notification ent=new Emailnotification();
	Notification wnt=new WhatsupNotification();
	nt.sendnotification();
	ent.sendnotification();
	wnt.sendnotification();
	
}
}
