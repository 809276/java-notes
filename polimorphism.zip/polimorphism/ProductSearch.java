package com.polimorphism;

public class ProductSearch {

	
	public void search(int pid) {
		System.out.println("product serach by id : "+pid);
	}
	
	public void search(String name) {
		System.out.println("product serach by name: "+name);
	}
	
	public void search(String name,int pid) {
		System.out.println("product serach by name and id : "+name+" and "+pid);
	}
	public static void main(String[] args) {
		ProductSearch ps=new ProductSearch();
		ps.search(123);
		ps.search("pen");
		ps.search("Car", 12);
	}
}
