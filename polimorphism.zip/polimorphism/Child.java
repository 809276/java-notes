package com.polimorphism;

class Mother{

	public void eat() {
		System.out.println("don't eat icecream :");
	}
}



public class Child extends Mother {

	@Override
	public void eat() {
		System.out.println("i want to eat icecream :");
	}
	public static void main(String[] args) {
		Child ch=new Child();
		ch.eat();
	}
}
