package com.polimorphism;

public class ShapeArea {

	public double area(double side) {
		return side*side;
	}
	
	public double are(double length,double width) {
		return length*width;
	}
	
	public double area(double radius,boolean isCircle) {
		return Math.PI*radius*radius;
	}
	
	public static void main(String[] args) {
		ShapeArea sa=new ShapeArea();
		System.out.println("area of rectangle:");
	}
}
