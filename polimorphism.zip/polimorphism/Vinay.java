package com.polimorphism;

class Parents{
	public void property(){
		
		System.out.println("100 cr property");
	}
	
	public void marriage() {
		System.out.println("arragre marriage");
	}
}
public class Vinay extends Parents{
	@Override
	public void marriage() {
		System.out.println("Love marriage");
	}
public static void main(String[] args) {
	Vinay v=new Vinay();
	v.property();
	v.marriage();
}
}
