package com.patterns;

public class Pattern2 {

	public static void main(String[] args) {
		int alpha=65;
		int r= 5;
		for(int i=1; i<=r; i++) {
			for(int j=1; j<=i; j++) {
				System.out.print((char)(alpha+j-1));
			}
			System.out.println();
		}
	}
}

//int alpha=65;
//int r=5;
//for(int i=1; i<=r; i++) {
//	for(int j=1; j<=i; j++) {
//		System.out.print((char)(alpha+j-1)+" ");
//	}
//	System.out.println();
//}