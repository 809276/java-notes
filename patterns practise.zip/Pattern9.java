package com.patterns;

public class Pattern9 {
	public static void main(String args[])
	{
		int alpha=65;
		int r=5;
		for(int i=1; i<=r; i++) {
			for(int j=r; j>=i; j--) {
				System.out.print(" ");
			}
			for(int k=1; k<=i; k++) {
				System.out.print((char)(alpha+k-1)+" ");
			}
			System.out.println();
	}
}}


//int alpha = 65;
//int r = 5;
//for (int m = r; m >= 1; m--) 
//       { 
//           for (int n = 1; n <= m; n++)
//	{
//		System.out.print(" ");
//	}
//	for (int p = m; p <= r; p++)
//	{
//		System.out.print((char) (alpha + p - 1) + " ");
//	}
//	System.out.println();
//}