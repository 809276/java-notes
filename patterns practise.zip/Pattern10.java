package com.patterns;

public class Pattern10 {
	public static void main(String args[])
	{
		
		int alpha=65;
		int r=5;
		for(int i=r; i>=1; i--) {
			for(int j=1; j<i; j++) {
				System.out.print(" ");
			}
			for(int k=i; k<=r; k++) {
				System.out.print((char)(alpha+k-1)+" ");
			}
			System.out.println();
		}
		
	}
}

//int alpha=65;
//int r=5;
//for(int i=r; i>=1; i--) {
//	for(int j=1; j<i; j++) {
//		System.out.print(" ");
//	}
//	for(int k=i; k<=r; k++) {
//		System.out.print((char)(alpha+k-1)+" ");
//	}
//	System.out.println();