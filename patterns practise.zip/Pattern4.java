package com.patterns;

public class Pattern4 {
	
		public static void main(String args[])
	    {
		int r=5;
		for(int i=1; i<=r; i++) {
		for(int j=1; j<=i; j++) {
			System.out.print(i+" ");
		}
		System.out.println();
		}
	    }
	}

//int alpha = 65;
//int r = 5;
//    for (int m = 1; m <= r; m++)
//    {
//        for (int n = 1; n <= m; n++)
//        {
//            System.out.print((char)(alpha + m -1) + " ");
//        }
//        System.out.println();
//    }