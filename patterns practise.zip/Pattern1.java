package com.patterns;

public class Pattern1 {

	public static void main(String args[])
    {
		char ch=65;
		int r=5;
		for(int i=1; i<=r; i++) {
			for(int j= 1; j<=i; j++) {
				System.out.print((char)(ch+j-1));
			}
			System.out.println();
		}
    }
}


//char ch=65;
////int r = 5;
//for (int m = 1; m <= r; m++)//m<=r -->6<=5
//{
//    for (int n = 1; n <= m; n++)//6<=5
//    {
//        System.out.print( (char)(ch+n-1)+" ");
//    }
//    System.out.println();
//}