package com.patterns;

public class Pattern5 {
public static void main(String[] args) {
	int alpha=65;
	int r=5;
	for(int i=1; i<=r; i++) {
		for(int j=1; j<=i; j++) {
			System.out.print((char)(alpha+i-1)+" ");
		}
		System.out.println();
	}
}
}


//int alpha=65;
//int r=5;
//for(int i=1; i<=r; i++) {
//	for (int j=1; j<=i; j++) {
//		System.out.print((char)(alpha+i-1)+" ");
//	}
//	System.out.println();
//}