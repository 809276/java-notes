package com.patterns;

public class Pattern8 {
	public static void main(String args[])
	{
		int r=5;
        for(int i=r; i>=1; i--) {
        	for(int j=1; j<i; j++) {
        		System.out.print(" ");
        	}
        	for(int k=i; k<=r; k++) {
        		System.out.print(k+" ");
        	}
        	System.out.println();
        }
	}
}

//int r=5;
//for(int i=r; i>=1; i--) {
//	for(int j=1; j<i; j++) {
//		System.out.print(" ");
//	}
//	for(int k=i; k<=r; k++) {
//		System.out.print(k+ " ");
//	}
//	System.out.println();
//}