package com.patterns;

public class Pattern7 {
	public static void main(String args[])
	{
	int r=5;
	for(int i=1; i<=r; i++) {
		for (int j=r; j>i; j--) {
			System.out.print(" ");
		}
		for(int k=1; k<=i; k++) {
			System.out.print(k+" ");
		}
		System.out.println();
	}
}}

//int r=5;
//for(int i=1; i<=r; i++) {
//	for(int j=r; j>i; j--) {
//		System.out.print(" ");
//	}
//	for(int p=1; p<=i;p++) {
//		System.out.print(p+" ");
//	}
//	System.out.println();
//}
//	}}