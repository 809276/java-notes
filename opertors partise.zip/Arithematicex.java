package com.operators;

public class Arithematicex {
	public static void main(String[] args) {
		int a=20;
		int b=35;
		int c=44;
		int d=66;
		System.out.println("The value of adition is:"+(a+b));// addition
		System.out.println("The value of subtraction is:"+(b-c));//subtraction
		System.out.println(" the value of Multiplication is :"+(a*c));// multiplication 
		System.out.println(" the value of  division is:"+(a/c));// division
		System.out.println(" the value of Modulo division is"+(c%d));// Modulo division
	}
}


