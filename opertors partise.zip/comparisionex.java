package com.operators;

import java.util.Scanner;

public class comparisionex {
	
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		  
		  
		System.out.println("Enter num1:");
		int num1 = sc.nextInt();
		System.out.println(" Enter num2:");
		 int num2 = sc.nextInt();
		 
		 if(num1<num2) {
			 System.out.println("Both integers are equal:");
		 }else
		 {
			 System.out.println(" Both integers are not equal:");
		 }
		
	}
	

}
