package com.operators;

import java.util.Scanner;

public class Logicex {
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter a number:");
		int num=sc.nextInt();
		if(!(num < 10 || num > 20)) {  
			System.out.println(num+" is with in the range:");
		}else
		{
			System.out.println(num+" is not in range:");
		}
		
	}

}
